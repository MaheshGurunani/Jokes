import java.util.Scanner;

public class Distributive {
    public static void main(String[] args) {
        int a, b, c;

        System.out.println("Enter three numbers:");
        Scanner sc = new Scanner(System.in);

        // Read three integers from user input
        a = sc.nextInt();
        b = sc.nextInt();
        c = sc.nextInt();

        // Output the distributive property of multiplication over addition
        System.out.println("Distributive Lab:");
        System.out.println("a * (b + c) -> " + (a * (b + c)));
        System.out.println("(a * b) + (a * c) -> " + ((a * b) + (a * c)));

        // Close the scanner
        sc.close();
    }
}
