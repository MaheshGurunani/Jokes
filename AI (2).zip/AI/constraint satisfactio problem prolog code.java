% Define the states and their adjacent relationships
adjacent(wa, sa).
adjacent(wa, nt).
adjacent(nt, sa).
adjacent(sa, qu).
adjacent(sa, nsw).
adjacent(ns, sa).
adjacent(ns, vz).
adjacent(qu, nsw).
adjacent(qu, vz).
adjacent(nsw, vz).

% Define that two states are different if they are adjacent
different(State1, State2) :-
    adjacent(State1, State2).

% Coloring predicate
color(State, Color) :- member(Color, [red, green, blue]).

% Main predicate to color all states
color_states(WA, SA, NT, QU, NSW, VZ) :-
    color(wa, WA),
    color(sa, SA),
    color(nt, NT),
    color(qu, QU),
    color(ns, NSW),
    color(vz, VZ),
    
    % Ensure adjacent states have different colors
    different(wa, sa),
    different(wa, nt),
    different(nt, sa),
    different(sa, qu),
    different(sa, nsw),
    different(ns, sa),
    different(ns, vz),
    different(qu, nsw),
    different(qu, vz),
    different(nsw, vz).

% Query to find a valid coloring
solve(Coloring) :-
    color_states(WA, SA, NT, QU, NSW, VZ),
    Coloring = [wa-WA, sa-SA, nt-NT, qu-QU, nsw-NSW, vz-VZ].
