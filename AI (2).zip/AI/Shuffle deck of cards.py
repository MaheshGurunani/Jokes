import itertools
import random

# Create a deck of cards
suits = ['Spades', 'Hearts', 'Diamonds', 'Clubs']
ranks = list(range(1, 14))  # 1 to 13 representing Ace to King
deck = list(itertools.product(ranks, suits))  # Create all combinations of ranks and suits

# Shuffle the deck
random.shuffle(deck)

# Deal 5 cards
print("You get:")
for i in range(5):
    rank, suit = deck[i]
    print(rank, "of", suit)
