import math

# Parameters
increment = 0.1
startingPoint = [1, 1]
points = [[1, 5], [6, 4], [5, 2], [2, 1]]

def distance(x1, y1, x2, y2):
    """Calculate the square of the distance between two points."""
    return math.pow(x2 - x1, 2) + math.pow(y2 - y1, 2)

def sumOfDistances(x1, y1, points):
    """Calculate the sum of distances from a point to a list of points."""
    return sum(distance(x1, y1, px[0], px[1]) for px in points)

def newDistance(x1, y1, points):
    """Calculate the total distance from a point to the list of points."""
    return [x1, y1, sumOfDistances(x1, y1, points)]

# Initialize minimum distance
minDistance = sumOfDistances(startingPoint[0], startingPoint[1], points)
flag = True
i = 1

while flag:
    # Calculate new distances for adjacent points
    d1 = newDistance(startingPoint[0] + increment, startingPoint[1], points)
    d2 = newDistance(startingPoint[0] - increment, startingPoint[1], points)
    d3 = newDistance(startingPoint[0], startingPoint[1] + increment, points)
    d4 = newDistance(startingPoint[0], startingPoint[1] - increment, points)

    print(i, ' ', round(startingPoint[0], 2), round(startingPoint[1], 2))

    # Find the minimum distance among the four new distances
    minimum = min(d1[2], d2[2], d3[2], d4[2])
    
    if minimum < minDistance:
        # Update the starting point if a new minimum is found
        if minimum == d1[2]:
            startingPoint = [d1[0], d1[1]]
        elif minimum == d2[2]:
            startingPoint = [d2[0], d2[1]]
        elif minimum == d3[2]:
            startingPoint = [d3[0], d3[1]]
        elif minimum == d4[2]:
            startingPoint = [d4[0], d4[1]]
        
        minDistance = minimum
        i += 1  # Increment iteration count
    else:
        flag = False  # Exit loop if no minimum found

print("Final point:", round(startingPoint[0], 2), round(startingPoint[1], 2))
print("Minimum distance:", round(minDistance, 2))
