# Define the graph
graph1 = {
    'A': set(['B', 'C']),
    'B': set(['A', 'D', 'E']),
    'C': set(['A', 'F']),
    'D': set(['B']),
    'E': set(['B', 'F']),
    'F': set(['C', 'E'])
}

def dfs(graph, node, visited):
    if node not in visited:
        visited.append(node)  # Mark the node as visited
        for n in graph[node]:  # Explore neighbors
            dfs(graph, n, visited)  # Recursively visit each neighbor
    return visited

# Start DFS from node 'A'
visited = dfs(graph1, 'A', [])
print("Visited nodes:", visited)
