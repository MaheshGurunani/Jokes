# Initial list with numbers and 0 in place of '+'
lis = [1, 2, 3, 4, 5, 6, 7, 0, 8]
print("Initial list:", lis)

def move_element(l):
    # Initialize step counter
    steps = 0
    
    # Continue moving until 9 steps have been completed
    while steps < 9:
        # Iterate through the list to find '0'
        for i in range(len(l)):
            if l[i] == 0:
                move = int(input("Enter 1 to move back or 0 to move ahead: "))
                
                if move == 1 and i > 0:  # Ensure not to go out of bounds
                    # Swap the current element with the previous one
                    l[i], l[i-1] = l[i-1], l[i]
                    steps += 1  # Increment step counter
                elif move == 0 and i < len(l) - 1:  # Ensure not to go out of bounds
                    # Swap the current element with the next one
                    l[i], l[i+1] = l[i+1], l[i]
                    steps += 1  # Increment step counter

                print("Updated list:", l)  # Print the updated list after each move
                break  # Break out of the for loop to restart the while loop

    return l

# Call the function to allow the user to move the '0'
final_list = move_element(lis)
print("Final list after 9 moves:", final_list)
