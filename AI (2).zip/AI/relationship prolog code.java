% Facts
male(john).
male(mike).
male(david).
male(paul).

female(susan).
female(linda).
female(anna).
female(mary).

% Parents
parents(john, mike).
parents(john, susan).
parents(mike, david).
parents(mike, linda).
parents(paul, anna).
parents(paul, mary).

% Rules
father(X, Y) :- male(X), parents(X, Y).
mother(X, Y) :- female(X), parents(X, Y).

grandfather(X, Y) :- male(X), parents(X, Z), parents(Z, Y).
grandmother(X, Y) :- female(X), parents(X, Z), parents(Z, Y).

brother(X, Y) :- male(X), parents(Z, X), parents(Z, Y), X \= Y.
sister(X, Y) :- female(X), parents(Z, X), parents(Z, Y), X \= Y.

uncle(X, Y) :- male(X), parents(Z, Y), (brother(X, Z) ; sister(X, Z)).
aunt(X, Y) :- female(X), parents(Z, Y), (brother(Z, X) ; sister(Z, X)).

nephew(X, Y) :- male(X), (brother(Y, Z) ; sister(Y, Z)), parents(Z, X).
niece(X, Y) :- female(X), (brother(Y, Z) ; sister(Y, Z)), parents(Z, X).

cousin(X, Y) :- parents(A, X), parents(B, Y), A \= B, (brother(A, B) ; sister(A, B)).
