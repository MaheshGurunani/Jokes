import java.util.Scanner;

public class Assct {
    public static void main(String[] args) {
        int a, b, c;

        System.out.println("Enter three numbers:");
        Scanner sc = new Scanner(System.in);

        // Read three integers from user input
        a = sc.nextInt();
        b = sc.nextInt();
        c = sc.nextInt();

        // Output the associative property of addition
        System.out.println("Associative Lab:");
        System.out.println("a + (b + c) -> " + (a + (b + c)));
        System.out.println("(a + b) + c -> " + ((a + b) + c));

        // Close the scanner
        sc.close();
    }
}
