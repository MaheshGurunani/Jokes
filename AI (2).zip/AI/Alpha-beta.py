# Example tree structure
tree = [[[5, 1, 2], [8, -8, -9]], [[9, 4, 5], [-3, 4, 3]]]
root = 0
pruned = 0

def children(branch, depth, alpha, beta):
    global tree
    global root
    global pruned
    i = 0
    for child in branch:
        if isinstance(child, list):  # Check if the child is a list (sub-tree)
            (nalpha, nbeta) = children(child, depth + 1, alpha, beta)
            if depth % 2 == 1:  # Minimizer's turn
                beta = min(nalpha, beta)
            else:  # Maximizer's turn
                alpha = max(nbeta, alpha)
            branch[i] = alpha if depth % 2 == 0 else beta
        else:  # Leaf node (integer value)
            if depth % 2 == 0:  # Maximizer's turn
                alpha = max(alpha, child)
            if depth % 2 == 1:  # Minimizer's turn
                beta = min(beta, child)
        
        # Alpha-Beta pruning
        if alpha >= beta:
            pruned += 1
            break  # Stop exploring this branch

        i += 1
        
    if depth == root:  # If we're at the root level, update the tree
        tree = alpha if root == 0 else beta
    return (alpha, beta)

def alphabeta(in_tree=tree, start=root, upper=-15, lower=15):
    global tree
    global pruned
    global root

    (alpha, beta) = children(tree, start, upper, lower)
    
    print("(alpha, beta): ", (alpha, beta))
    print("Result: ", tree)
    print("Times pruned: ", pruned)
    
    return (alpha, beta, tree, pruned)

if __name__ == "__main__":
    alphabeta()
