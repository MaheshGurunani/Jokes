# Function to print the Tic-Tac-Toe board
def print_board(board):
    for row in board:
        print(" | ".join(row))
        print("-" * 5)

# Function to check for a winner
def check_winner(board, player):
    # Check rows, columns, and diagonals
    for row in board:
        if all([cell == player for cell in row]):
            return True
    
    for col in range(3):
        if all([board[row][col] == player for row in range(3)]):
            return True
    
    if all([board[i][i] == player for i in range(3)]) or all([board[i][2 - i] == player for i in range(3)]):
        return True

    return False

# Function to check if the board is full (tie)
def check_tie(board):
    for row in board:
        if any([cell == ' ' for cell in row]):
            return False
    return True

# Function to handle the player's move
def make_move(board, player):
    while True:
        try:
            move = int(input(f"Player {player}, enter your move (1-9): "))
            if move < 1 or move > 9:
                print("Invalid move. Please enter a number between 1 and 9.")
                continue
            row, col = divmod(move - 1, 3)
            if board[row][col] == ' ':
                board[row][col] = player
                break
            else:
                print("This position is already taken. Try again.")
        except ValueError:
            print("Invalid input. Please enter a number between 1 and 9.")

# Function to play the Tic-Tac-Toe game
def play_game():
    board = [[' ' for _ in range(3)] for _ in range(3)]
    current_player = 'X'

    print("Welcome to Tic-Tac-Toe!")
    print_board(board)

    while True:
        # Make a move
        make_move(board, current_player)
        print_board(board)

        # Check for a winner
        if check_winner(board, current_player):
            print(f"Player {current_player} wins!")
            break
        
        # Check for a tie
        if check_tie(board):
            print("It's a tie!")
            break

        # Switch players
        current_player = 'O' if current_player == 'X' else 'X'

# Start the game
play_game()
