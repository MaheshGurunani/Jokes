% Facts
batsman(william_son).
bowler(boult).
keeper(marsh).

% Rule to determine if a cricketer is a batsman, bowler, or keeper
cricketer(X) :- batsman(X).
cricketer(X) :- bowler(X).
cricketer(X) :- keeper(X).

% Rule to check if a cricketer is a batsman
is_batsman(X) :- batsman(X).

% Rule to check if a cricketer is a bowler
is_bowler(X) :- bowler(X).

% Rule to check if a cricketer is a keeper
is_keeper(X) :- keeper(X).
